"""Avatar panel — shows the user's twin.

Modes:
- "d_id"     : full talking-head MP4 played whenever the assistant speaks
- "waveform" : static portrait + animated waveform (cheap, no D-ID render cost)

The panel exposes:
- `speak(text)` — start a render and play when ready (mode-aware)
- `set_level(level)` — drive the waveform while user is recording / twin is talking
- `pop_out()` — detach the avatar to a borderless, transparent, always-on-top
  window so OBS can window-capture just the twin's face for streaming.
- `talk_requested` — grandmother-simple compact window (face + chat). Owned by
  MainWindow; this panel only mirrors the live face into it.

Pop-out mode keeps an `_BroadcastWindow` instance and mirrors playback into
it (the same QMediaPlayer drives a second QVideoWidget by reparenting).
The compact talk window uses the same single video sink when it is visible.
"""
from __future__ import annotations

import math
import os
import tempfile
from typing import Optional

import requests
from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QStackedLayout,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .. import api, config
from . import PALETTE
from .aura import Aura


class _Waveform(QWidget):
    """A simple amplitude-following ring that pulses at `set_level`."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setMinimumHeight(120)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._level = 0.0
        self._phase = 0.0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(33)
        self.setAutoFillBackground(False)

    def set_level(self, level: float) -> None:
        self._level = max(0.0, min(1.0, level))

    def _tick(self) -> None:
        # Decay so it returns to idle when not driven
        self._level *= 0.92
        self._phase = (self._phase + 0.08) % (2 * math.pi)
        self.update()

    def paintEvent(self, _ev) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = self.rect()
        cx = rect.center().x()
        cy = rect.center().y()
        max_r = min(rect.width(), rect.height()) * 0.42
        accent = QColor(PALETTE["accent"])
        # 3 concentric rings, each modulated by phase + level
        for i in range(3):
            radius = max_r * (0.55 + 0.15 * i + 0.18 * self._level * math.sin(self._phase + i))
            alpha = int(180 - i * 50)
            pen = QPen(QColor(accent.red(), accent.green(), accent.blue(), alpha))
            pen.setWidthF(1.5)
            p.setPen(pen)
            p.drawEllipse(int(cx - radius), int(cy - radius), int(radius * 2), int(radius * 2))
        p.end()


class _PortraitVideo(QStackedWidget):
    """Either the user's portrait JPG, or a QVideoWidget playing D-ID output."""

    portrait_loaded = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._portrait_url: Optional[str] = None

        self._portrait = QLabel()
        self._portrait.setAlignment(Qt.AlignCenter)
        self._portrait.setStyleSheet(
            "background: transparent; border-radius: 6px;"
        )
        self.addWidget(self._portrait)

        self._video = QVideoWidget()
        self._video.setStyleSheet("background: transparent;")
        self.addWidget(self._video)

        self.setCurrentIndex(0)

    def set_portrait_url(self, url: Optional[str]) -> None:
        if not url or url == self._portrait_url:
            return
        self._portrait_url = url
        # Fetch in a thread, set when done
        def _fetch():
            try:
                r = requests.get(url, timeout=15)
                r.raise_for_status()
                return r.content
            except Exception:
                return b""
        api._submit(_fetch, self._on_portrait, None)  # type: ignore[attr-defined]

    def _on_portrait(self, data: bytes) -> None:
        if not data:
            return
        pm = QPixmap()
        if pm.loadFromData(data):
            scaled = pm.scaled(
                self.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation,
            )
            self._portrait.setPixmap(scaled)
            self._portrait._raw = pm  # keep for re-scale on resize
            self.portrait_loaded.emit()

    def show_portrait(self) -> None:
        self.setCurrentIndex(0)

    def show_video(self) -> QVideoWidget:
        self.setCurrentIndex(1)
        return self._video

    def resizeEvent(self, ev) -> None:  # noqa: N802
        super().resizeEvent(ev)
        raw = getattr(self._portrait, "_raw", None)
        if raw is not None:
            self._portrait.setPixmap(
                raw.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )


class _BroadcastWindow(QWidget):
    """Frameless, transparent-background window used for OBS window-capture.

    OBS picks this up by name ("Heirloom Twin — Broadcast"). We keep an
    internal QVideoWidget that we play the same MP4 into for parity with
    the main panel.
    """

    closed = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Heirloom Twin — Broadcast")
        # Frameless + transparent so OBS captures only the face
        self.setWindowFlags(
            Qt.Window
            | Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.resize(420, 420)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.portrait = QLabel(self)
        self.portrait.setAlignment(Qt.AlignCenter)
        self.portrait.setStyleSheet("background: transparent;")
        self.video = QVideoWidget(self)
        self.video.setStyleSheet("background: transparent;")
        self.video.hide()
        layout.addWidget(self.portrait)
        layout.addWidget(self.video)

        # Drag-to-move
        self._drag_pos = None

    def mousePressEvent(self, ev):  # noqa: N802
        if ev.button() == Qt.LeftButton:
            self._drag_pos = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()
            ev.accept()

    def mouseMoveEvent(self, ev):  # noqa: N802
        if self._drag_pos and ev.buttons() & Qt.LeftButton:
            self.move(ev.globalPosition().toPoint() - self._drag_pos)
            ev.accept()

    def closeEvent(self, ev):  # noqa: N802
        self.closed.emit()
        super().closeEvent(ev)


class AvatarPanel(QFrame):
    """Center-stage avatar with controls."""

    status_changed = Signal(str)  # "idle" | "thinking" | "speaking"
    talk_requested = Signal()  # open the compact "just the twin" window

    def __init__(self, settings: dict, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("avatar_panel")
        self._settings = settings
        self._broadcast: Optional[_BroadcastWindow] = None
        self._talk = None
        self._tmp_video: Optional[str] = None

        # Media
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        # -----------------------------------------------------------------
        # Windows-Mixer fix: QAudioOutput on Windows registers its session
        # at whatever tiny default the OS picks unless we ALWAYS set volume
        # explicitly. Without this call the app appears pinned at ~1% in the
        # Volume Mixer and the slider can't be raised. Also read from config
        # so a user who lowered it in-app doesn't have their setting stomped.
        try:
            _twin_vol = float(config.load_settings().get("twin_playback_volume", 1.0))
        except Exception:  # noqa: BLE001
            _twin_vol = 1.0
        # Clamp: 0.0-1.0 per Qt docs. Anything < 0.05 causes the "stuck at 1"
        # Windows Mixer symptom — floor it so users can't accidentally lock
        # themselves out via a slider mishap.
        _twin_vol = max(0.05, min(1.0, _twin_vol))
        self.audio.setVolume(_twin_vol)
        # -----------------------------------------------------------------
        self.player.setAudioOutput(self.audio)
        self.player.mediaStatusChanged.connect(self._on_media_status)
        self.player.errorOccurred.connect(self._on_media_error)

        # Layout
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 14)
        root.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("Your twin")
        title.setProperty("class", "overline")
        title.setStyleSheet(
            f"color: {PALETTE['text_muted']}; letter-spacing: 2px; font-size: 10px;"
        )
        header.addWidget(title)
        header.addStretch(1)

        self.btn_mode = QPushButton("Avatar: D-ID")
        self.btn_mode.setObjectName("ghost")
        self.btn_mode.clicked.connect(self._toggle_mode)
        header.addWidget(self.btn_mode)

        self.btn_talk = QPushButton("Talk in a small window")
        self.btn_talk.setObjectName("ghost")
        self.btn_talk.setToolTip("Just you and your twin — the big window hides")
        self.btn_talk.clicked.connect(self.talk_requested.emit)
        header.addWidget(self.btn_talk)

        self.btn_popout = QPushButton("Pop out for OBS ↗")
        self.btn_popout.setObjectName("ghost")
        self.btn_popout.clicked.connect(self.pop_out)
        header.addWidget(self.btn_popout)
        root.addLayout(header)

        # Stage — aura underneath, portrait_video on top (StackAll = z-order overlay)
        stage = QWidget()
        stage.setAttribute(Qt.WA_StyledBackground, False)
        stack = QStackedLayout(stage)
        stack.setStackingMode(QStackedLayout.StackAll)
        stack.setContentsMargins(0, 0, 0, 0)
        self.aura = Aura(stage)
        self.portrait_video = _PortraitVideo(stage)
        # Add aura FIRST so it's beneath (StackAll draws in insertion order)
        stack.addWidget(self.aura)
        stack.addWidget(self.portrait_video)
        self.portrait_video.portrait_loaded.connect(self._mirror_faces)
        root.addWidget(stage, 1)

        self.waveform = _Waveform(self)
        self.waveform.hide()
        root.addWidget(self.waveform)

        self.status_label = QLabel("idle")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet(
            f"color: {PALETTE['text_muted']}; letter-spacing: 2px; font-size: 10px;"
        )
        root.addWidget(self.status_label)

        self._apply_mode()

    # ---- public ----
    def set_portrait_url(self, url: Optional[str]) -> None:
        self.portrait_video.set_portrait_url(url)
        self._mirror_faces()

    def set_level(self, level: float) -> None:
        self.waveform.set_level(level)
        # Feed the aura too — makes the halo pulse with the voice
        if hasattr(self, "aura"):
            self.aura.set_level(level)

    def set_aura_state(self, status: str) -> None:
        """Public — main_window drives this from unified status updates."""
        if hasattr(self, "aura"):
            self.aura.set_state(status)

    def set_status(self, status: str) -> None:
        labels = {
            "idle": "idle",
            "thinking": "thinking…",
            "speaking": "speaking",
            "listening": "listening…",
            "rendering": "rendering twin…",
        }
        self.status_label.setText(labels.get(status, status))
        if hasattr(self, "aura"):
            self.aura.set_state(status)
        self.status_changed.emit(status)

    def speak(self, text: str) -> None:
        """Render the assistant `text` as the twin's voice + face, then play."""
        text = (text or "").strip()
        if not text:
            self.set_status("idle")
            return
        if self._settings.get("avatar_mode") == "waveform":
            # No D-ID render — but if the user has a cloned voice we still
            # *speak*. The waveform ring pulses for the duration of playback.
            self._speak_via_tts(text)
            return
        self.set_status("rendering")
        api.post_async(
            "/desktop/avatar/talk",
            {"text": text[:1000]},
            on_ok=self._on_talk_started,
            on_err=lambda msg: self.set_status("idle"),
        )

    def _speak_via_tts(self, text: str) -> None:
        """Waveform-mode voice path: fetch cloned-voice MP3, play through the
        same QMediaPlayer, animate the waveform for its duration. If the user
        hasn't configured a voice, silently pulse for ~1.8s."""
        self.set_status("rendering")

        def _fetch():
            import tempfile

            import requests as _r

            url = config.BACKEND_URL.rstrip("/") + "/api/desktop/speak"
            headers = {
                "Authorization": f"Bearer {config.DEVICE_TOKEN}",
                "Content-Type": "application/json",
            }
            r = _r.post(url, json={"text": text[:4000]}, headers=headers, timeout=60)
            if r.status_code == 400:
                # Voice not configured → bubble up via a sentinel so the UI
                # can fall back to the silent pulse without an error toast.
                return {"unconfigured": True}
            if r.status_code >= 400:
                raise RuntimeError(f"TTS {r.status_code}: {r.text[:200]}")
            f = tempfile.NamedTemporaryFile(
                suffix=".mp3", delete=False, prefix="heirloom_tts_"
            )
            f.write(r.content)
            f.flush()
            f.close()
            return {"path": f.name}

        api._submit(_fetch, self._on_tts_ready, self._on_tts_err)  # type: ignore[attr-defined]

    def _on_tts_ready(self, result: dict) -> None:
        if result.get("unconfigured"):
            # Graceful fallback — silent pulse for a beat.
            self.set_status("speaking")
            QTimer.singleShot(1800, lambda: self.set_status("idle"))
            return
        path = result.get("path")
        if not path:
            self.set_status("idle")
            return
        # Clean previous tmp file
        if self._tmp_video and os.path.exists(self._tmp_video):
            try:
                os.unlink(self._tmp_video)
            except Exception:
                pass
        self._tmp_video = path
        self.set_status("speaking")
        # Audio-only path: don't switch to video widget, keep showing the
        # portrait. The waveform widget below it stays visible and we drive
        # its level from a periodic timer while audio is playing.
        self.portrait_video.show_portrait()
        self.player.setVideoOutput(None)  # type: ignore[arg-type]
        self.player.setSource(QUrl.fromLocalFile(path))
        self._start_tts_pulse()
        self.player.play()

    def _on_tts_err(self, msg: str) -> None:
        # Silent fallback — log to console; the UI just goes back to idle.
        print(f"[avatar] TTS failed: {msg}")
        self.set_status("speaking")
        QTimer.singleShot(1500, lambda: self.set_status("idle"))

    def _start_tts_pulse(self) -> None:
        """While TTS is playing, modulate the waveform ring with a synthetic
        envelope so the ring actually *pulses* with the speech. We don't
        do real spectrum analysis (would need QAudioProbe/FFT) — instead a
        cheap random walk that feels natural."""
        if not hasattr(self, "_pulse_timer"):
            self._pulse_timer = QTimer(self)
            self._pulse_timer.timeout.connect(self._tts_pulse_tick)
        self._pulse_timer.start(80)

    def _tts_pulse_tick(self) -> None:
        import random

        if self.player.playbackState() != QMediaPlayer.PlayingState:
            self._pulse_timer.stop()
            self.set_level(0.0)
            return
        # Soft envelope: bias around 0.55 with random fluctuation
        self.set_level(0.35 + random.random() * 0.45)

    def pop_out(self) -> None:
        if self._broadcast is not None and self._broadcast.isVisible():
            self._broadcast.raise_()
            return
        if self._broadcast is None:
            self._broadcast = _BroadcastWindow(self)
            self._broadcast.closed.connect(self._on_broadcast_closed)
        # Geometry recall
        geo = self._settings.get("pop_out_geometry")
        if isinstance(geo, list) and len(geo) == 4:
            self._broadcast.setGeometry(*geo)
        # Mirror current portrait
        raw = getattr(self.portrait_video._portrait, "_raw", None)
        if raw is not None:
            self._broadcast.portrait.setPixmap(
                raw.scaled(
                    self._broadcast.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            )
        self._broadcast.show()
        self._mirror_faces()
        self._route_video_output()

    def attach_talk_window(self, window) -> None:
        """MainWindow owns the compact talk window; we only mirror the face."""
        self._talk = window
        self._mirror_faces()
        self._route_video_output()

    def _talk_visible(self) -> bool:
        return self._talk is not None and self._talk.isVisible()

    def _broadcast_visible(self) -> bool:
        return self._broadcast is not None and self._broadcast.isVisible()

    def _portrait_raw(self):
        return getattr(self.portrait_video._portrait, "_raw", None)

    def _mirror_faces(self) -> None:
        raw = self._portrait_raw()
        if raw is None:
            return
        if self._broadcast is not None:
            self._broadcast.portrait.setPixmap(
                raw.scaled(
                    self._broadcast.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            )
        if self._talk is not None:
            self._talk.set_portrait(raw)

    def _route_video_output(self) -> None:
        """Qt allows one video sink per player. Prefer the window the user is looking at."""
        playing = self.player.playbackState() == QMediaPlayer.PlayingState
        if self._talk_visible():
            self.player.setVideoOutput(self._talk.video)
            if playing:
                self._talk.show_video_surface()
            return
        if self._broadcast_visible():
            self.player.setVideoOutput(self._broadcast.video)
            if playing:
                self._broadcast.video.show()
                self._broadcast.portrait.hide()
            return
        if playing:
            video = self.portrait_video.show_video()
            self.player.setVideoOutput(video)

    # ---- internal ----
    def _toggle_mode(self) -> None:
        new = "waveform" if self._settings.get("avatar_mode") == "d_id" else "d_id"
        self._settings["avatar_mode"] = new
        config.save_settings(self._settings)
        self._apply_mode()

    def _apply_mode(self) -> None:
        mode = self._settings.get("avatar_mode", "d_id")
        if mode == "waveform":
            self.btn_mode.setText("Avatar: Waveform")
            self.waveform.show()
        else:
            self.btn_mode.setText("Avatar: D-ID")
            self.waveform.hide()

    def _on_talk_started(self, data: dict) -> None:
        talk_id = (data or {}).get("talk_id")
        if not talk_id:
            self.set_status("idle")
            return
        self._poll_talk(talk_id, attempts=0)

    def _poll_talk(self, talk_id: str, attempts: int) -> None:
        if attempts > 40:  # ~40 * 1500ms = 60s budget
            self.set_status("idle")
            return
        api.get_async(
            f"/desktop/avatar/talk/{talk_id}",
            on_ok=lambda d: self._on_talk_poll(talk_id, d, attempts),
            on_err=lambda _msg: QTimer.singleShot(
                1500, lambda: self._poll_talk(talk_id, attempts + 1)
            ),
        )

    def _on_talk_poll(self, talk_id: str, data: dict, attempts: int) -> None:
        status = (data or {}).get("status", "")
        url = (data or {}).get("result_url")
        if status == "done" and url:
            self._play_result(url)
        elif status in ("error", "rejected"):
            self.set_status("idle")
        else:
            QTimer.singleShot(1500, lambda: self._poll_talk(talk_id, attempts + 1))

    def _play_result(self, url: str) -> None:
        self.set_status("speaking")
        # Download to a tmp file so QMediaPlayer doesn't have to stream over
        # a redirect-laden CDN — QMediaPlayer can be picky on Windows.
        def _fetch():
            try:
                r = requests.get(url, timeout=30)
                r.raise_for_status()
                f = tempfile.NamedTemporaryFile(
                    suffix=".mp4", delete=False, prefix="heirloom_"
                )
                f.write(r.content)
                f.flush()
                f.close()
                return f.name
            except Exception as exc:
                raise RuntimeError(f"download: {exc}") from exc

        api._submit(_fetch, self._on_video_ready, lambda _m: self.set_status("idle"))  # type: ignore[attr-defined]

    def _on_video_ready(self, path: str) -> None:
        # Clean up the previous tmp
        if self._tmp_video and os.path.exists(self._tmp_video):
            try:
                os.unlink(self._tmp_video)
            except Exception:
                pass
        self._tmp_video = path
        video = self.portrait_video.show_video()
        self.player.setVideoOutput(video)
        # One sink: compact talk window first, then OBS broadcast, then this panel.
        if self._talk_visible():
            self.player.setVideoOutput(self._talk.video)
            self._talk.show_video_surface()
        elif self._broadcast_visible():
            self.player.setVideoOutput(self._broadcast.video)
            self._broadcast.video.show()
            self._broadcast.portrait.hide()
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()

    def _on_media_status(self, status: QMediaPlayer.MediaStatus) -> None:
        if status == QMediaPlayer.EndOfMedia:
            self.set_status("idle")
            self.portrait_video.show_portrait()
            if self._broadcast_visible():
                self._broadcast.video.hide()
                self._broadcast.portrait.show()
            if self._talk_visible():
                self._talk.show_portrait_surface()

    def _on_media_error(self, _err, _msg: str = "") -> None:
        self.set_status("idle")
        self.portrait_video.show_portrait()
        if self._talk_visible():
            self._talk.show_portrait_surface()

    # --- Public: volume control ---------------------------------------
    def set_playback_volume(self, volume: float) -> None:
        """Set the twin's voice playback volume (0.0-1.0). Persists to config.

        Enforces a 0.05 floor because a QAudioOutput session created at ~0 on
        Windows sticks in the Volume Mixer at 1% and the OS won't let it be
        raised without restarting the app.
        """
        try:
            v = max(0.05, min(1.0, float(volume)))
        except (TypeError, ValueError):
            return
        self.audio.setVolume(v)
        try:
            s = config.load_settings()
            s["twin_playback_volume"] = v
            config.save_settings(s)
        except Exception:  # noqa: BLE001
            pass

    def playback_volume(self) -> float:
        """Read back the current playback volume (0.0-1.0)."""
        try:
            return float(self.audio.volume())
        except Exception:  # noqa: BLE001
            return 1.0

    def _on_broadcast_closed(self) -> None:
        if self._broadcast is not None:
            self._settings["pop_out_geometry"] = [
                self._broadcast.x(),
                self._broadcast.y(),
                self._broadcast.width(),
                self._broadcast.height(),
            ]
            config.save_settings(self._settings)
